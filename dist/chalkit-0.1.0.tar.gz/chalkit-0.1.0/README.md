# CLI to save ideas/todos by just opening your terminal.
